#!/bin/bash

echo "Executing Pre-API Helpers"